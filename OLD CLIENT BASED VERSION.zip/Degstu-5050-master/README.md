# Degstu-5050
See http://5050.degstu.com/

index.html - UI

process.php - Does the dirty work, creating links and such

l - folder w/ all the links, cookie library

l/index.html - redirects to root index.html

